# Spaceship Simulator

## Installation

The following instructions assume you have `bower` and `python` installed.

`bower install`

## Usage

`python -m SimpleHTTPServer`

Open a web browser and go to `http://localhost:8000`.

## Credits

Jiun Wei Chia, jiunwei.moe@gmail.com

## License

Copyright 2015-2016 Ministry of Education, Singapore. All rights reserved.
